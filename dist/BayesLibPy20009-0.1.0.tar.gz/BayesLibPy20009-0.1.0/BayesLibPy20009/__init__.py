from BayesNet import BayesianNetwork


